using UnityEngine.UI;

namespace UnityEditor.UI
{
    [CustomEditor(typeof(RectMask2D), true)]
    [CanEditMultipleObjects]
    public class RectMask2DEditor : Editor
    {
        public override void OnInspectorGUI()
        {
        }
    }
}
